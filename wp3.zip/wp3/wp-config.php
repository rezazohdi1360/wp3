<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp3_db' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'hgQb!F7Vwl }1Hr3oa{n),++|Ky```8emIIf DM<;x,45IosvE95lF#1*Eesk>RR' );
define( 'SECURE_AUTH_KEY',  '|G2-gI`o(Vq(h9Ak!9DGK{g_b}kL&$TIL~tq.jawSAD+J{T56V4[=Tg*xcU9Kq&.' );
define( 'LOGGED_IN_KEY',    'd[UBxu4U4hEjl`Fz^*{7!7-Vkxn]xB+P7i])%)^P*PB.3m~DJtUvhshY{ogV7ryC' );
define( 'NONCE_KEY',        'J{w&KBK]1>@#LSsmcXLv&<.:2H/h4[x&yP!uO*!<zC@^x[VM=xktem^$VE0g_dB=' );
define( 'AUTH_SALT',        '1BPd@JSACBJNW0g2*35+m?@9@z!=&]3x^lX%(zAO&!>#bgR1)MK3!z6~_1w~) u%' );
define( 'SECURE_AUTH_SALT', ';ZPWD;SoS}-wmr~LUWx7za[cu6;aaz.*bwc+*<AbW+u^j1-o_nCUog`AP*-yv^8J' );
define( 'LOGGED_IN_SALT',   '#pIZTa/5/IJ;C1]x{0PS=mo^]qqHE.W6#f8z9:yoi@>WU ;tLtu+;#L,M`M.2OD}' );
define( 'NONCE_SALT',       '.@;(:GI&LT[BJ-^-bOGYHy:1%,Xby K02dlpIr&=]M--S0(Y{6{I<bTddx!ae`&|' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
